"""
Carga los 3 planes (Básico / Estándar / Premium) con sus funciones y
límites, según el diseño híbrido que definimos. Correr una sola vez
(o cada vez que se actualicen los límites/precios de los planes).
"""
from app.database import SessionLocal
from app import models

PLANES = [
    dict(
        id="basico", nombre="Básico", precio_mensual=9900,
        permite_codigo_barras=False, permite_mercado_pago=False,
        permite_dashboard=False, permite_facturacion_afip=False,
        limite_productos=50, limite_ventas_mes=300,
        limite_usuarios=1, limite_sucursales=1,
    ),
    dict(
        id="estandar", nombre="Estándar", precio_mensual=18900,
        permite_codigo_barras=True, permite_mercado_pago=True,
        permite_dashboard=False, permite_facturacion_afip=False,
        limite_productos=500, limite_ventas_mes=3000,
        limite_usuarios=3, limite_sucursales=1,
    ),
    dict(
        id="premium", nombre="Premium", precio_mensual=32900,
        permite_codigo_barras=True, permite_mercado_pago=True,
        permite_dashboard=True, permite_facturacion_afip=True,
        limite_productos=None, limite_ventas_mes=None,
        limite_usuarios=None, limite_sucursales=None,
    ),
]


def main():
    db = SessionLocal()
    try:
        for data in PLANES:
            existente = db.query(models.Plan).filter(models.Plan.id == data["id"]).first()
            if existente:
                for k, v in data.items():
                    setattr(existente, k, v)
            else:
                db.add(models.Plan(**data))
        db.commit()
        print(f"Cargados {len(PLANES)} planes correctamente.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
