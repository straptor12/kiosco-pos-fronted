"""politicas RLS multi-tenant

Esta es la migracion clave del proyecto: activa Row-Level Security en
las 4 tablas que tienen tenant_id, y crea una politica que compara esa
columna contra app.current_tenant (seteado por la app en cada request,
ver app/deps.py). A partir de aca, Postgres nunca deja que una consulta
vea o modifique filas de otro tenant, sin importar que el codigo del
backend se olvide de filtrar por tenant_id.

Revision ID: 7566f600c154
Revises: 6eaee126710f
Create Date: 2026-08-05 03:46:52.344960

"""
from alembic import op

revision = '7566f600c154'
down_revision = '6eaee126710f'
branch_labels = None
depends_on = None

TABLAS_CON_TENANT = ["productos", "ventas", "venta_items"]
# 'usuarios' queda afuera a propósito: el login busca por email antes de
# tener un tenant en contexto (todavía no sabemos a qué kiosco pertenece
# quien se está logueando). Ahí el aislamiento se garantiza distinto:
# el JWT que se emite en el login trae el tenant_id fijo, y todos los
# queries posteriores (productos, ventas) sí pasan por RLS.


def upgrade():
    for tabla in TABLAS_CON_TENANT:
        op.execute(f"ALTER TABLE {tabla} ENABLE ROW LEVEL SECURITY;")
        # FORCE hace que la politica aplique incluso al dueño de la tabla
        # (por defecto Postgres exime al owner, lo cual anularia la RLS
        # si la app se conecta con ese mismo usuario).
        op.execute(f"ALTER TABLE {tabla} FORCE ROW LEVEL SECURITY;")
        op.execute(f"""
            CREATE POLICY tenant_isolation_{tabla} ON {tabla}
            USING (tenant_id::text = current_setting('app.current_tenant', true))
            WITH CHECK (tenant_id::text = current_setting('app.current_tenant', true));
        """)


def downgrade():
    for tabla in TABLAS_CON_TENANT:
        op.execute(f"DROP POLICY IF EXISTS tenant_isolation_{tabla} ON {tabla};")
        op.execute(f"ALTER TABLE {tabla} DISABLE ROW LEVEL SECURITY;")
