import uuid
from datetime import datetime

from sqlalchemy import (
    Column, String, Integer, Numeric, DateTime, ForeignKey, Boolean, JSON
)
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship

from app.database import Base


def gen_uuid():
    return str(uuid.uuid4())


class Plan(Base):
    """
    Catálogo de planes: Básico / Estándar / Premium.
    Guardar las funciones y límites acá (y no hardcodeados en el código)
    permite cambiar un límite o agregar un plan nuevo sin tocar el backend.
    """
    __tablename__ = "planes"

    id = Column(String, primary_key=True)  # 'basico' | 'estandar' | 'premium'
    nombre = Column(String, nullable=False)
    precio_mensual = Column(Numeric(10, 2), nullable=False)

    # Funciones habilitadas
    permite_codigo_barras = Column(Boolean, default=False)
    permite_mercado_pago = Column(Boolean, default=False)
    permite_dashboard = Column(Boolean, default=False)
    permite_facturacion_afip = Column(Boolean, default=False)

    # Límites de uso (null = ilimitado)
    limite_productos = Column(Integer, nullable=True)
    limite_ventas_mes = Column(Integer, nullable=True)
    limite_usuarios = Column(Integer, nullable=True)
    limite_sucursales = Column(Integer, nullable=True)


class Tenant(Base):
    """Cada kiosco/local que usa el sistema. Es la unidad de aislamiento (RLS)."""
    __tablename__ = "tenants"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    nombre = Column(String, nullable=False)
    plan_id = Column(String, ForeignKey("planes.id"), nullable=False, default="basico")
    creado_en = Column(DateTime, default=datetime.utcnow)

    plan = relationship("Plan")
    usuarios = relationship("Usuario", back_populates="tenant")
    productos = relationship("Producto", back_populates="tenant")
    ventas = relationship("Venta", back_populates="tenant")


class Usuario(Base):
    __tablename__ = "usuarios"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    tenant_id = Column(UUID(as_uuid=False), ForeignKey("tenants.id"), nullable=False)
    email = Column(String, nullable=False, index=True)
    password_hash = Column(String, nullable=False)
    rol = Column(String, default="empleado")  # 'dueno' | 'empleado'
    creado_en = Column(DateTime, default=datetime.utcnow)

    tenant = relationship("Tenant", back_populates="usuarios")


class Producto(Base):
    __tablename__ = "productos"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    tenant_id = Column(UUID(as_uuid=False), ForeignKey("tenants.id"), nullable=False)
    nombre = Column(String, nullable=False)
    codigo_barras = Column(String, nullable=True, index=True)
    precio = Column(Numeric(10, 2), nullable=False)
    stock = Column(Integer, nullable=False, default=0)
    creado_en = Column(DateTime, default=datetime.utcnow)

    tenant = relationship("Tenant", back_populates="productos")


class Venta(Base):
    __tablename__ = "ventas"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    tenant_id = Column(UUID(as_uuid=False), ForeignKey("tenants.id"), nullable=False)
    total = Column(Numeric(10, 2), nullable=False)
    metodo_pago = Column(String, nullable=False, default="efectivo")  # 'efectivo' | 'mercadopago'
    creado_en = Column(DateTime, default=datetime.utcnow)

    tenant = relationship("Tenant", back_populates="ventas")
    items = relationship("VentaItem", back_populates="venta", cascade="all, delete-orphan")


class VentaItem(Base):
    __tablename__ = "venta_items"

    id = Column(UUID(as_uuid=False), primary_key=True, default=gen_uuid)
    tenant_id = Column(UUID(as_uuid=False), ForeignKey("tenants.id"), nullable=False)
    venta_id = Column(UUID(as_uuid=False), ForeignKey("ventas.id"), nullable=False)
    producto_id = Column(UUID(as_uuid=False), ForeignKey("productos.id"), nullable=False)
    nombre_producto = Column(String, nullable=False)  # copia histórica del nombre
    cantidad = Column(Integer, nullable=False)
    precio_unitario = Column(Numeric(10, 2), nullable=False)

    venta = relationship("Venta", back_populates="items")
