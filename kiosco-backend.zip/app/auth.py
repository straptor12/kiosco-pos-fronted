from datetime import datetime, timedelta

import bcrypt
from jose import jwt, JWTError

from app.config import settings


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))


def create_access_token(tenant_id: str, usuario_id: str, rol: str) -> str:
    """
    El JWT lleva el tenant_id embebido. Es la pieza clave de la seguridad:
    el usuario nunca elige a qué tenant quiere acceder — viene fijo en su
    token desde el login, y de ahí se usa para setear `app.current_tenant`
    en cada request (ver deps.py).
    """
    expire = datetime.utcnow() + timedelta(minutes=settings.jwt_expire_minutes)
    payload = {
        "tenant_id": tenant_id,
        "usuario_id": usuario_id,
        "rol": rol,
        "exp": expire,
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def decode_access_token(token: str) -> dict | None:
    try:
        return jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    except JWTError:
        return None
