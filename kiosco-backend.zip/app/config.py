from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    database_url: str = "postgresql://kiosco_app:kiosco_dev_pass@localhost:5432/kiosco_pos"
    jwt_secret: str = "cambiar-este-secreto-en-produccion"
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = 60 * 12  # 12 horas

    class Config:
        env_file = ".env"


settings = Settings()
