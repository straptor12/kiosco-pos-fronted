from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routers import auth, productos, ventas, planes

app = FastAPI(
    title="Kiosco·POS API",
    description="Backend multi-tenant para el sistema de punto de venta de kioscos.",
    version="0.1.0",
)

# En producción, reemplazar "*" por el dominio real del frontend.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(productos.router)
app.include_router(ventas.router)
app.include_router(planes.router)


@app.get("/health")
def health():
    return {"status": "ok"}
