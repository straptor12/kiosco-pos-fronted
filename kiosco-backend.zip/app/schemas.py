from datetime import datetime
from decimal import Decimal
from typing import Optional, List

from pydantic import BaseModel, EmailStr


# ---------- Auth ----------
class RegistroTenant(BaseModel):
    nombre_kiosco: str
    email_dueno: EmailStr
    password: str
    plan_id: str = "basico"


class Login(BaseModel):
    email: EmailStr
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    tenant_id: str
    tenant_nombre: str
    plan_id: str


# ---------- Productos ----------
class ProductoCreate(BaseModel):
    nombre: str
    codigo_barras: Optional[str] = None
    precio: Decimal
    stock: int = 0


class ProductoOut(BaseModel):
    id: str
    nombre: str
    codigo_barras: Optional[str]
    precio: Decimal
    stock: int

    class Config:
        from_attributes = True


# ---------- Ventas ----------
class VentaItemIn(BaseModel):
    producto_id: str
    cantidad: int


class VentaCreate(BaseModel):
    items: List[VentaItemIn]
    metodo_pago: str = "efectivo"  # 'efectivo' | 'mercadopago'


class VentaItemOut(BaseModel):
    nombre_producto: str
    cantidad: int
    precio_unitario: Decimal

    class Config:
        from_attributes = True


class VentaOut(BaseModel):
    id: str
    total: Decimal
    metodo_pago: str
    creado_en: datetime
    items: List[VentaItemOut]

    class Config:
        from_attributes = True


# ---------- Plan ----------
class PlanOut(BaseModel):
    id: str
    nombre: str
    precio_mensual: Decimal
    permite_codigo_barras: bool
    permite_mercado_pago: bool
    permite_dashboard: bool
    permite_facturacion_afip: bool
    limite_productos: Optional[int]
    limite_ventas_mes: Optional[int]
    limite_usuarios: Optional[int]
    limite_sucursales: Optional[int]

    class Config:
        from_attributes = True
