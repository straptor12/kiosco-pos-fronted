from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app import models, schemas
from app.deps import get_tenant_db, get_current_context, TenantContext

router = APIRouter(prefix="/planes", tags=["planes"])


@router.get("", response_model=list[schemas.PlanOut])
def listar_planes(db: Session = Depends(get_tenant_db)):
    return db.query(models.Plan).all()


@router.get("/actual", response_model=schemas.PlanOut)
def mi_plan(
    db: Session = Depends(get_tenant_db),
    ctx: TenantContext = Depends(get_current_context),
):
    tenant = db.query(models.Tenant).filter(models.Tenant.id == ctx.tenant_id).first()
    return tenant.plan
