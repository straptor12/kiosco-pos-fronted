from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.deps import get_tenant_db, get_current_context, TenantContext, check_limite, require_feature

router = APIRouter(prefix="/ventas", tags=["ventas"])


@router.get("", response_model=list[schemas.VentaOut])
def listar_ventas(
    db: Session = Depends(get_tenant_db),
    ctx: TenantContext = Depends(get_current_context),
):
    return db.query(models.Venta).order_by(models.Venta.creado_en.desc()).all()


@router.post("", response_model=schemas.VentaOut, status_code=201)
def registrar_venta(
    data: schemas.VentaCreate,
    db: Session = Depends(get_tenant_db),
    ctx: TenantContext = Depends(get_current_context),
):
    if not data.items:
        raise HTTPException(status_code=400, detail="La venta no tiene items")

    if data.metodo_pago == "mercadopago":
        require_feature(db, ctx, "permite_mercado_pago")

    # límite de ventas del mes (según el plan)
    inicio_mes = datetime.utcnow().replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    ventas_este_mes = db.query(models.Venta).filter(models.Venta.creado_en >= inicio_mes).count()
    check_limite(db, ctx, "limite_ventas_mes", ventas_este_mes)

    # traemos y bloqueamos los productos involucrados, validamos stock
    productos_by_id = {}
    for item in data.items:
        producto = (
            db.query(models.Producto)
            .filter(models.Producto.id == item.producto_id)
            .with_for_update()
            .first()
        )
        if not producto:
            raise HTTPException(status_code=404, detail=f"Producto {item.producto_id} no existe")
        if producto.stock < item.cantidad:
            raise HTTPException(
                status_code=409,
                detail=f"Stock insuficiente para '{producto.nombre}' (quedan {producto.stock})",
            )
        productos_by_id[item.producto_id] = producto

    total = sum(productos_by_id[i.producto_id].precio * i.cantidad for i in data.items)

    venta = models.Venta(tenant_id=ctx.tenant_id, total=total, metodo_pago=data.metodo_pago)
    db.add(venta)
    db.flush()

    for item in data.items:
        producto = productos_by_id[item.producto_id]
        producto.stock -= item.cantidad
        db.add(models.VentaItem(
            tenant_id=ctx.tenant_id,
            venta_id=venta.id,
            producto_id=producto.id,
            nombre_producto=producto.nombre,
            cantidad=item.cantidad,
            precio_unitario=producto.precio,
        ))

    db.commit()
    db.refresh(venta)
    return venta


@router.get("/resumen-hoy")
def resumen_hoy(
    db: Session = Depends(get_tenant_db),
    ctx: TenantContext = Depends(get_current_context),
):
    """Base para el 'cierre de caja diario' del plan Estándar+."""
    inicio_dia = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    ventas = db.query(models.Venta).filter(models.Venta.creado_en >= inicio_dia).all()
    por_metodo = {}
    for v in ventas:
        por_metodo[v.metodo_pago] = por_metodo.get(v.metodo_pago, 0) + float(v.total)
    return {
        "cantidad_ventas": len(ventas),
        "total": sum(float(v.total) for v in ventas),
        "por_metodo_pago": por_metodo,
    }
