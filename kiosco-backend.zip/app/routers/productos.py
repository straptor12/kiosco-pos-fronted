from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app import models, schemas
from app.deps import get_tenant_db, get_current_context, TenantContext, check_limite

router = APIRouter(prefix="/productos", tags=["productos"])


@router.get("", response_model=list[schemas.ProductoOut])
def listar_productos(
    db: Session = Depends(get_tenant_db),
    ctx: TenantContext = Depends(get_current_context),
):
    # Gracias a RLS, este query "trae todo" pero Postgres ya lo filtra
    # solo a los productos del tenant_id seteado en la sesión.
    return db.query(models.Producto).order_by(models.Producto.nombre).all()


@router.post("", response_model=schemas.ProductoOut, status_code=201)
def crear_producto(
    data: schemas.ProductoCreate,
    db: Session = Depends(get_tenant_db),
    ctx: TenantContext = Depends(get_current_context),
):
    conteo_actual = db.query(models.Producto).count()
    check_limite(db, ctx, "limite_productos", conteo_actual)

    producto = models.Producto(
        tenant_id=ctx.tenant_id,
        nombre=data.nombre,
        codigo_barras=data.codigo_barras,
        precio=data.precio,
        stock=data.stock,
    )
    db.add(producto)
    db.commit()
    db.refresh(producto)
    return producto


@router.get("/buscar/{codigo_o_nombre}", response_model=list[schemas.ProductoOut])
def buscar_producto(
    codigo_o_nombre: str,
    db: Session = Depends(get_tenant_db),
    ctx: TenantContext = Depends(get_current_context),
):
    """Usado por la Caja: matchea código de barras exacto o nombre parcial."""
    exacto = db.query(models.Producto).filter(models.Producto.codigo_barras == codigo_o_nombre).all()
    if exacto:
        return exacto
    return db.query(models.Producto).filter(
        models.Producto.nombre.ilike(f"%{codigo_o_nombre}%")
    ).all()


@router.delete("/{producto_id}", status_code=204)
def eliminar_producto(
    producto_id: str,
    db: Session = Depends(get_tenant_db),
    ctx: TenantContext = Depends(get_current_context),
):
    producto = db.query(models.Producto).filter(models.Producto.id == producto_id).first()
    if not producto:
        raise HTTPException(status_code=404, detail="Producto no encontrado")
    db.delete(producto)
    db.commit()
