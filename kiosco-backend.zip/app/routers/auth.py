from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session

from app import models, schemas
from app.auth import hash_password, verify_password, create_access_token
from app.database import get_db

router = APIRouter(prefix="/auth", tags=["auth"])


@router.post("/registro", response_model=schemas.TokenResponse, status_code=201)
def registrar_tenant(data: schemas.RegistroTenant, db: Session = Depends(get_db)):
    """
    Alta de un kiosco nuevo (tenant) + su usuario dueño.
    Esta es una de las pocas operaciones que NO pasa por RLS de un tenant
    existente — porque acá es donde se crea el tenant en sí.
    """
    plan = db.query(models.Plan).filter(models.Plan.id == data.plan_id).first()
    if not plan:
        raise HTTPException(status_code=400, detail="Plan inválido")

    existe = db.query(models.Usuario).filter(models.Usuario.email == data.email_dueno).first()
    if existe:
        raise HTTPException(status_code=400, detail="Ya existe una cuenta con ese email")

    tenant = models.Tenant(nombre=data.nombre_kiosco, plan_id=plan.id)
    db.add(tenant)
    db.flush()  # para tener tenant.id antes del commit

    usuario = models.Usuario(
        tenant_id=tenant.id,
        email=data.email_dueno,
        password_hash=hash_password(data.password),
        rol="dueno",
    )
    db.add(usuario)
    db.commit()
    db.refresh(tenant)
    db.refresh(usuario)

    token = create_access_token(tenant.id, usuario.id, usuario.rol)
    return schemas.TokenResponse(
        access_token=token, tenant_id=tenant.id, tenant_nombre=tenant.nombre, plan_id=tenant.plan_id
    )


@router.post("/login", response_model=schemas.TokenResponse)
def login(data: schemas.Login, db: Session = Depends(get_db)):
    usuario = db.query(models.Usuario).filter(models.Usuario.email == data.email).first()
    if not usuario or not verify_password(data.password, usuario.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Email o contraseña incorrectos")

    tenant = db.query(models.Tenant).filter(models.Tenant.id == usuario.tenant_id).first()
    token = create_access_token(tenant.id, usuario.id, usuario.rol)
    return schemas.TokenResponse(
        access_token=token, tenant_id=tenant.id, tenant_nombre=tenant.nombre, plan_id=tenant.plan_id
    )
