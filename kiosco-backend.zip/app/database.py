"""
Configuración de la conexión a PostgreSQL.

El truco del multi-tenant con RLS está acá: cada vez que abrimos una sesión
para atender un request, seteamos `app.current_tenant` en esa conexión.
Las políticas RLS de Postgres (ver alembic/versions/..._rls_policies.py)
usan ese valor para filtrar automáticamente todas las consultas — así,
aunque el código de un endpoint se olvide de filtrar por tenant_id,
la base de datos nunca deja ver datos de otro kiosco.
"""
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, declarative_base

from app.config import settings

engine = create_engine(settings.database_url, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    """Sesión de DB simple, sin tenant seteado (para login, alta de tenant, etc.)."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def get_tenant_db(tenant_id: str):
    """
    Devuelve una dependencia de FastAPI que abre una sesión con
    `app.current_tenant` seteado al tenant_id indicado. Todo lo que se
    consulte con esta sesión queda automáticamente filtrado por RLS.
    """
    def _get_db():
        db = SessionLocal()
        try:
            db.execute(text("SET app.current_tenant = :tid"), {"tid": tenant_id})
            yield db
        finally:
            db.close()
    return _get_db
