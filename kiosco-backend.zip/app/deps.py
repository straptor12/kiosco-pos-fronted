from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.auth import decode_access_token
from app.database import SessionLocal
from app import models

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


class TenantContext:
    def __init__(self, tenant_id: str, usuario_id: str, rol: str):
        self.tenant_id = tenant_id
        self.usuario_id = usuario_id
        self.rol = rol


def get_current_context(token: str = Depends(oauth2_scheme)) -> TenantContext:
    payload = decode_access_token(token)
    if not payload:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Token inválido o vencido")
    return TenantContext(payload["tenant_id"], payload["usuario_id"], payload["rol"])


def get_tenant_db(ctx: TenantContext = Depends(get_current_context)):
    """
    Sesión de DB con `app.current_tenant` seteado según el token del usuario.
    A partir de acá, cualquier SELECT/INSERT que haga el endpoint queda
    automáticamente acotado a ese tenant por las políticas RLS de Postgres —
    aunque el código del endpoint se olvide de filtrar por tenant_id,
    la base de datos no deja ver ni tocar datos de otro kiosco.
    """
    db = SessionLocal()
    try:
        db.execute(text("SET app.current_tenant = :tid"), {"tid": ctx.tenant_id})
        yield db
    finally:
        db.close()


def get_current_plan(db: Session, tenant_id: str) -> models.Plan:
    tenant = db.query(models.Tenant).filter(models.Tenant.id == tenant_id).first()
    return tenant.plan


def check_limite(db: Session, ctx: TenantContext, campo_limite: str, conteo_actual: int):
    """
    Chequea un límite numérico del plan (productos, ventas/mes, usuarios).
    Si el límite es None, el plan no tiene tope (Premium). Si se llegó al
    tope, corta con un 402 (Payment Required) sugiriendo el upgrade.
    """
    plan = get_current_plan(db, ctx.tenant_id)
    limite = getattr(plan, campo_limite)
    if limite is not None and conteo_actual >= limite:
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail=f"Alcanzaste el límite de tu plan ({plan.nombre}). Actualizá de plan para seguir.",
        )


def require_feature(db: Session, ctx: TenantContext, campo_feature: str):
    """Corta con 402 si el plan actual no tiene habilitada una función (ej: Mercado Pago)."""
    plan = get_current_plan(db, ctx.tenant_id)
    if not getattr(plan, campo_feature):
        raise HTTPException(
            status_code=status.HTTP_402_PAYMENT_REQUIRED,
            detail=f"Esta función no está disponible en tu plan ({plan.nombre}). Actualizá de plan para usarla.",
        )
