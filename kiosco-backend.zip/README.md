# Kiosco·POS — Backend

API multi-tenant (FastAPI + PostgreSQL con Row-Level Security) para el
sistema de punto de venta de kioscos. Cada kiosco es un "tenant"
completamente aislado del resto — aunque comparten la misma base de
datos y aplicación.

## Cómo está armado

```
app/
  main.py         → arranca la API y registra los routers
  config.py       → variables de entorno (DATABASE_URL, JWT_SECRET, etc.)
  database.py     → conexión a Postgres + helper para setear el tenant activo
  models.py       → tablas: tenants, planes, usuarios, productos, ventas, venta_items
  schemas.py      → validación de requests/responses (Pydantic)
  auth.py         → hash de contraseñas (bcrypt) y JWT
  deps.py         → quién es el usuario logueado, chequeo de límites de plan
  routers/
    auth.py       → POST /auth/registro, POST /auth/login
    productos.py  → alta/listado/búsqueda/baja de productos
    ventas.py     → registrar venta, descuenta stock, resumen del día
    planes.py     → consulta de planes disponibles

alembic/
  versions/
    ..._tablas_iniciales.py       → crea las tablas
    ..._politicas_rls_multi_tenant.py → activa RLS y las políticas de aislamiento

seed_planes.py    → carga los 3 planes (Básico/Estándar/Premium) con sus
                     límites y funciones habilitadas
```

## El aislamiento multi-tenant, en criollo

1. Cada fila de `productos`, `ventas` y `venta_items` tiene una columna `tenant_id`.
2. Esas tablas tienen **Row-Level Security** activado en Postgres, con una
   política que compara `tenant_id` contra `app.current_tenant`.
3. Cuando un usuario hace login, recibe un **JWT** con su `tenant_id` adentro.
4. En cada request, `app/deps.py` lee ese `tenant_id` del token y ejecuta
   `SET app.current_tenant = '<id>'` en la conexión antes de correr cualquier
   consulta.
5. A partir de ahí, aunque el código de un endpoint se olvide de filtrar por
   `tenant_id`, **Postgres nunca va a devolver ni dejar modificar filas de
   otro kiosco**. Esto ya se probó a mano (ver sección de pruebas abajo) y
   funciona.

## Los 3 planes

Definidos en `seed_planes.py`, cargados en la tabla `planes`. Cambiar un
límite o precio ahí (y volver a correr el script) no requiere tocar código
del resto del sistema — todo el resto (`deps.py`) lee esa tabla.

| | Básico | Estándar | Premium |
|---|---|---|---|
| Código de barras | ❌ | ✅ | ✅ |
| Mercado Pago | ❌ | ✅ | ✅ |
| Dashboard / AFIP | ❌ | ❌ | ✅ |
| Productos | 50 | 500 | ilimitado |
| Ventas/mes | 300 | 3.000 | ilimitado |

## Correrlo en tu máquina

Necesitás Python 3.12 y PostgreSQL instalado y corriendo.

```bash
# 1. Crear la base y el usuario (una sola vez)
psql -c "CREATE USER kiosco_app WITH PASSWORD 'kiosco_dev_pass';"
psql -c "CREATE DATABASE kiosco_pos OWNER kiosco_app;"

# 2. Entorno virtual + dependencias
python3 -m venv venv
./venv/bin/pip install -r requirements.txt

# 3. Variables de entorno
cp .env.example .env
# (editá .env si tu conexión a Postgres es distinta)

# 4. Migraciones + planes
PYTHONPATH=. ./venv/bin/alembic upgrade head
PYTHONPATH=. ./venv/bin/python seed_planes.py

# 5. Levantar el servidor
PYTHONPATH=. ./venv/bin/uvicorn app.main:app --reload
```

La API queda en `http://localhost:8000`. La documentación interactiva
(Swagger) está en `http://localhost:8000/docs` — ahí podés probar todos
los endpoints sin escribir código.

## Deploy en Railway

1. Subí este proyecto a un repositorio de GitHub.
2. En Railway: **New Project → Deploy from GitHub repo**.
3. Agregá un plugin de **PostgreSQL** al proyecto (Railway te da la
   variable `DATABASE_URL` automáticamente, conectada a tu servicio).
4. En las variables de entorno del servicio backend, agregá `JWT_SECRET`
   con un valor largo y random (no dejes el de ejemplo).
5. Railway detecta el `Dockerfile` y lo despliega solo. El propio contenedor
   corre las migraciones y carga los planes al arrancar (ver `CMD` del
   Dockerfile), así que no hace falta ningún paso manual extra.

## Pruebas manuales que ya se corrieron (y pasaron)

- Registro de 2 kioscos distintos + login de cada uno
- Alta de productos en cada kiosco
- Confirmado que cada kiosco **solo ve sus propios productos** (aislamiento RLS)
- Venta con Mercado Pago en plan Estándar → funciona
- Venta con Mercado Pago en plan Básico → rechazada con `402` (como se
  espera, ya que Básico no incluye esa función)
- Venta en efectivo → descuenta stock correctamente

## Lo que falta (próximos pasos)

- Conectar el **frontend** (el prototipo de Caja) a esta API en vez de
  a `window.storage`
- Endpoints de **cierre de caja** más completos y **dashboard** (Premium)
- Integración real con la **API de Mercado Pago** (hoy el flujo de
  `metodo_pago` está listo para recibirlo, falta el webhook real)
- **Facturación AFIP** (plan Premium)
- Recuperar/cambiar contraseña, y gestión de usuarios adicionales por tenant
